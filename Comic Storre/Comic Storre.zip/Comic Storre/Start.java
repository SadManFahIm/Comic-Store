import java.lang.*;

public class Start
{
	static public void main(String args[])
	{
		Login lg = new Login();
		lg.setVisible(true);
	}
}